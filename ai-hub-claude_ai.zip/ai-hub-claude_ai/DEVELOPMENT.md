# Development handoff — 2026-09-12

## User intent
Continue coding autonomously. Give regular progress updates (user requested at least once in 15 minutes); explain stage and exact required action when stopping. User explicitly authorized publishing current code to GitHub main on 2026-09-12. No paid LLM provider selected yet; do not ask for keys in chat.

## Current state
- Version 0.5, Node 24, native modules, SQLite, Ukrainian vanilla UI, no runtime npm dependencies.
- Server http://127.0.0.1:4317; start with npm start.
- Store layering: Store -> ResearchStore -> AssessmentStore -> TaskStore -> PlanStore, server uses PlanStore.
- 35 tests pass and isolated headless Edge browser smoke passes.
- Browser smoke covers project creation, source verification, structured assessment, schedules, recurring completion, research plan adoption, reload and mobile overflow; no JS errors.
- Playwright package is bundled at the runtime path discoverable through load_workspace_dependencies. Run with PLAYWRIGHT_MODULE pointing at that package. npm run test:browser.
- CUA and view_image helpers fail with setup refresh / trusted Node errors; headless browser through approved shell works.
- Sandbox helper repeatedly fails; approved escalated commands work. Do not infer missing workspace authorization.
- Local main and origin configured; first push to main verified at 4b62671. data directory ignored by Git.
- Live DB has real Ink Builder Program and network-docs research records. Do not mark source verified or user actions complete without user confirmation.

## Completed additions
1. Assessments with evidence and immutable revisions; source changes invalidate revisions in the same transaction.
2. Five manual scoring signals, coverage, separate risk/costs/deadline fields. No reward probabilities.
3. Exact timestamp/calendar validation, schedules, optimistic revisions, idempotent recurring completion; missing periods never invented as completed.
4. Rule-based research cues with exact source offsets, review-before-adoption, deterministic task IDs and stale evidence checks.
5. All new UI flows validated in a separate in-memory test server.

## Next work
- Await provider preference before configuring paid AI services; provider-neutral work can continue.
- Ink apps catalogue now reads public JSON data literals from same-origin Next.js assets without executing downloaded JavaScript. Saves names, descriptions and HTTPS websites in the source snapshot; individual app import remains future work.
- Wallet / chain receipt verification and transaction simulation are not implemented.
- API remains local single-user only; no on-chain execution, credential storage or external account access.
- Monitor only runs while server is alive, opt-in every 6h. Its current setting is not automatically changed.

## Latest addition
Cross-project agenda implemented and browser-tested; /api/agenda refreshes independently from forms. Current push request fulfilled; continued with agenda feature.

## Outcome ledger
OutcomeLedger is composed with the main store by the server. Records manual rewards/expenses, exact asset quantities and cent-valuations, unknown-value handling, idempotent requests and auditable voids. Browser smoke now covers record/void. No actual transactions or price lookups.

## Backups
POST /api/backup streams a session-protected SQLite backup. Temp files cleaned explicitly; portable DELETE journal avoids leftover WAL files. Restore CLI validates integrity/FKs/tables and reserves destination exclusively, refusing existing DB and sidecars. DROP_HUNTER_DB_PATH allows opening restored DB separately. Full round-trip and browser download tested.

## Погоджені джерела та ШІ-аналіз
Див. [RESEARCH_ROADMAP.md](RESEARCH_ROADMAP.md): шість джерел, запропонованих користувачем, вимоги до агентів, доказів, оцінки витрат і ризиків та етапи реалізації. Інтеграції цих джерел ще не реалізовані.

## Загальний список кандидатів
Пріоритет Ink скасовано за уточненням користувача. Додано пошук за назвою/нотатками та збережені статуси new/watching/active/paused/dismissed. Невідома або кілька мереж — окремий дозволений варіант. Статус не підтверджує винагороду та не змінює виконання завдань.
Початкова добірка асистента у research-candidates.json, імпорт у запущений локальний застосунок: node scripts/import-candidates.mjs. Повторний імпорт пропускає наявні назви. Це добірка за відкритими трекерами, не автономний LLM-пошук. Автоматичні адаптери шести трекерів і ШІ-модуль ще потребують реалізації.

## Пошук із трекера
Кнопка «Знайти нові проєкти» викликає POST /api/discovery/projects та читає публічні картки Airdrops.io. До 40 кандидатів за запит, інтервал 60 секунд, дублікати за назвою/URL пропускаються. Існуючі нотатки, статуси й перевірки не перезаписуються. Джерело та час записуються в нотатки. Це імпорт кандидатів без ШІ-оцінки; інші трекери ще не підключені. 37 тестів та браузерний сценарій кнопки пройшли.

## Пріоритет джерел — уточнення користувача
1. CryptoRank: https://cryptorank.io/ru/drophunting
2. Incrypted: https://incrypted.com/airdrops/
Ці два джерела підключати першими. Збирати не лише назви кандидатів, а й покрокові плани участі, посилання на дії, дедлайни та дату перевірки. Зберігати версії планів, показувати додані/змінені кроки; не перезаписувати власні завдання користувача й не скидати виконання без його рішення. Виявлені зміни умов позначати для повторного перегляду.
Airdrops.io — додаткове джерело. DropsTab, CertiK Skynet та AirdropAlert залишаються у плані. Пріоритет джерел не означає пріоритет окремої мережі.
Поточний автоматичний імпорт усе ще використовує Airdrops.io; інтеграції двох основних джерел ще не реалізовані.

План сервера, Android, Telegram та робота: [ASSISTANT_ROADMAP.md](ASSISTANT_ROADMAP.md).

## Локальний ШІ — перший етап
ПК: Intel i5-1235U, 16 GB RAM, Intel Iris Xe. Ollama 0.34.0, модель qwen3:4b. API викликається лише через 127.0.0.1:11434; платні сервіси не налаштовані.
Робот має чат із локальною моделлю, вибором проєкту й історією SQLite (agent_messages). На картці кнопка «Аналіз локальним ШІ» зберігає чернетку у settings agentReview:<id>. Ці висновки не підтверджують джерело, не змінюють завдання та не означають нову перевірку сайту. Модель не має інструментів виконання чи браузера.
Це перший локальний модуль аналізу й діалогу, не завершена система автономного пошуку. Автоматичне навчання ваг, щоденний моніторинг основних трекерів і взаємодія окремих агентів залишаються наступними етапами. Уточнення користувача враховуються через останню історію розмови.
Запуск середовища: відкрити Ollama, потім npm start. Модель встановлюється командою ollama pull qwen3:4b.

Уточнення користувача: Ollama, моделі та журнали фізично зберігати лише на диску D. Каталоги D:\AI\Ollama, D:\AI\OllamaData, D:\AI\OllamaLogs. Старі шляхи на C — лише junction для сумісності. OLLAMA_MODELS=D:\AI\OllamaData\models.

Після живої перевірки базову qwen3:4b замінено на qwen3:4b-instruct: базова модель ігнорувала вимкнення міркування. Обірвані відповіді (done_reason=length) не зберігати.

## Latest research/import work
Incrypted is now the preferred tracker option; 31 live candidates imported. DailyResearch checks watching/active Incrypted cards once daily while server runs, keeps previous snapshot, and triggers local analysis on changes. Full guide retrieval is a separate button using a public instruction link; guide text is passed to local analysis. CryptoRank still returns 403 to direct reads. MaterialImport accepts user-pasted CryptoRank text (16k chars), stores immutable versions, deduplicates unchanged content, invalidates manual verification on change. Browser session access remains unavailable; no cookies copied or challenge bypassed. 43 tests pass plus existing browser smoke. Server/Telegram/full autonomous cross-source search remain incomplete.

## CryptoRank API integration (2026-09-13)
Added a real integration with CryptoRank's official REST API (`api.cryptorank.io/v3`, `X-Api-Key` header) as a 4th tracker source (`sourceId: 'cryptorank'` in TrackerSearch), separate from the earlier abandoned attempt at scraping the `cryptorank.io/ru/drophunting` website directly (that one hit a bot-protection 403 and is unrelated to this) and separate from the newer `browser-extension/cryptorank-reader` (reads the page as the logged-in user in their own browser). Field names in the parser (`parseCryptorankDrophunting`) are inferred from CryptoRank's public docs and website display fields — not confirmed against a real response, since this development environment had no network access to `api.cryptorank.io`. CryptoRank's own migration docs (`docs.cryptorank.io/migration/endpoints-mapping`) list **Business** as the minimum plan for Drophunting endpoints specifically; a lower-tier key may get a 401/403 that is a plan limitation, not a bug — the code surfaces that distinctly from other failures. The API key is read from `CRYPTORANK_API_KEY` (see `.env.example`), never hardcoded; `npm start`/`npm run dev` now use Node's native `--env-file-if-exists` flag to load `.env` without adding a dependency. MaterialImport (manual paste) and the browser extension remain as fallbacks if the live API call is rejected for plan reasons. The real first run against the live API is the actual contract test for the response shape, not the unit tests here.

## Prepared-action layer: queue instead of one-by-one prompts (2026-09-14)
Added the missing piece behind the existing `taskKinds`/`taskPolicy` approval-gate design (domain.mjs): a `prepareTask(id, payload)` on Store that lets an agent (or a human) stage what a task actually requires — a link + suggested text for `kind: 'social'`, or a summary + free-form params for on-chain kinds — without ever signing or sending anything. `queue()` returns every prepared, not-yet-completed task across all projects grouped by network, approval-gate kinds sorted first within each group, so the user can switch wallet/account once per network and clear everything in that group instead of context-switching per task. Wired at `POST /api/tasks/:id/prepare` and `GET /api/queue`. Added `liquidity` to `taskKinds`/approval list (swaps/bridges/stake/mint/deploy/contract-call/liquidity all require explicit per-transaction user confirmation — no autonomous signing, confirmed as a hard requirement, not a default, after explicit discussion: prompt-injection risk from analyzing third-party project text, and small-auto-approve-limits are exactly how agent wallets get drained). `src/social-links.mjs` builds safe Discord/Twitter/Telegram deep links (join/follow/post) from the project's own text — no credentials or OAuth ever touch this app, the user always clicks the actual action in their own logged-in tab. Discord/Twitter/Telegram were explicitly requested as platforms to account for; more platforms can be added to `socialPlatforms` + a new builder in social-links.mjs without touching the queue/store layer. 70 tests pass. Still open: the queue has no UI yet (public/), and no on-chain payload *builder* exists (params are free-form JSON an agent fills in by hand for now) — see "Still to build" below.

### Still to build on this layer
- **Queue UI** (public/): a page rendering `GET /api/queue` grouped by network, with a "prepare" form per task calling `POST /api/tasks/:id/prepare`.
- **On-chain payload builders per action kind** (swap/bridge/stake/liquidity/deploy/mint/contract-call): today `params` in a prepared payload is free-form JSON with no schema per kind — building an actual calldata/simulation preview (the "show exactly what will happen before you sign" idea from the design discussion) is real chain-specific work, not done yet.
- **Local-agent wiring**: `local-agents.mjs` doesn't call `prepareTask`/social-links yet — the agent roles discussed (discovery / risk analyst / reward classifier / task extractor / planner) aren't implemented as such; only the data layer they'd write into exists so far.

## Queue UI + social-plan (2026-09-16)
Built the UI half of the prepared-action layer: `public/queue.js` (`renderQueue`, mounted at `#queue-content`, grouped by network like the design discussion specified) and `public/social.js` (`socialPanel`, mirrors `research.js`'s draft→checkbox→adopt pattern exactly). Added `src/social-plan.mjs`: extracts Discord/Twitter/Telegram links **verbatim from the verified source text** (same evidence-with-exact-offsets principle as `research-plan.mjs` — nothing is guessed or LLM-generated), filters out non-account Twitter paths (`/home`, `/search`, `/intent`, etc.) so a reserved path never gets presented as "the project's account". `PlanStore.adoptSocialAction` turns selected draft items directly into queue-ready prepared tasks (no separate manual prepareTask step needed since the evidence is already solid) — same staleness guard as adoptResearch (rejects if the source changed since the draft was drawn). Routes: `GET /api/projects/:id/social-draft`, `POST /api/projects/:id/social-plan`.

**Caught and fixed a real bug via an actual headless-browser run (Playwright + chromium, not just `node --test`)**: `social.js` and `queue.js` were written and imported by `app.js` but never added to `server.mjs`'s static-file allowlist — the missing entries 404, and since it's an ES module import, that failure is fatal and would have broken the *entire* frontend (not just these two features), invisibly, since none of the `node --test` suite loads a real browser or checks static file serving for these paths. Added a regression test (`test/app.test.mjs`) that reads every `from './X.js'` import in `app.js` and asserts the server actually serves each one — confirmed it fails red without the fix and passes green with it, so this class of bug can't silently ship again. 74 tests pass.

Verified end-to-end in a real headless browser (not just unit tests): two projects on different networks, live-open the social panel, tick checkboxes, submit, watch the queue grow and group correctly by network (Base/Arbitrum) with correct titles, links, and policy labels, zero console errors.

### Still open
- On-chain payload *builders* per action kind (swap/bridge/stake/liquidity/deploy/mint/contract-call) — `params` in a prepared payload is still free-form JSON with no per-kind schema or calldata/simulation preview. This is real per-chain research (router contracts, ABIs) and deliberately was not rushed — see the earlier discussion on why autonomous signing is out of scope and why even payload *preparation* for funds-moving actions needs care.
- `local-agents.mjs` still doesn't call `social-plan.mjs`/`prepareTask` automatically during the daily research cycle — a human still opens the social panel manually per project. Wiring the daily agent to surface "N new social links found, ready to add to queue" is the natural next step once the queue UI (this) is confirmed working for you locally.
- No UI test running in CI/automatically — the Playwright check that caught the allowlist bug was a manual one-off in this session, not `npm run test:browser` (that script requires msedge specifically, matching your Windows setup, not this environment).

## Learning: source reliability + cross-project lessons (2026-09-16)
Answers "чи навчаються агенти?" the way the project's original design doc specified: accumulated verified memory, not model fine-tuning. `src/learning.mjs`:
- `sourceReliability(store)` — groups all projects by source domain (incrypted.com, dropstab.com, cryptorank.io, a project's own site...) and counts how many led to a recorded reward (via OutcomeLedger) vs expense-only vs no outcome yet vs dismissed. Answers "which sources are actually worth the time" from real recorded history, not vibes.
- `lessonsDigest(store, limit)` — pulls every project's `agentFeedback` where the user marked an analysis "inaccurate" and explained why, across ALL projects (not just the one being analyzed), newest first.
`lessonsDigest` is now injected into every `local-agents.mjs` analysis as a clearly labeled "Уроки з інших проєктів" section, with an explicit system-prompt instruction not to transfer specific numbers/names from it into the current project's analysis — it's stylistic/cautionary context, not a fact source. `GET /api/learning` bundled into `/api/state` (guarded the same way `tracker`/`monitor` already are, since `createApp` is also exercised in tests with a bare `Store` that has no `.setting()` — this exact gap crashed `/api/state` entirely on first attempt, caught by the existing HTTP round-trip test, not a new one). New `public/learning.js` panel (`#learning`) shows both signals.

**Existing test intentionally rewritten, not just fixed**: `agent-feedback.test.mjs` used to assert total cross-project isolation ("project P's feedback must never appear in project Q's prompt") — that was correct before this feature existed, and is now the wrong assertion on purpose. Rewrote it to check the real current contract: P's feedback never leaks into Q's *direct* same-project feedback section, but legitimately appears — only there, only labeled — inside the "Уроки з інших проєктів" section. Documented inline in the test why the assertion changed, so it doesn't read as an unexplained weakening later.

Caught two more missing-static-file-allowlist misses the same way as before (`learning.js` itself, twice — once from a stale mental note, confirmed the auto-generated regression test in `app.test.mjs` catches this class of bug every time now, so it stays cheap to keep re-forgetting this one thing). 79 tests pass; also re-verified via a real headless-browser run (Playwright + chromium, not just `node --test`) with real outcome + feedback data — the panel renders both sections correctly with zero console errors.

### Note on the .env/data incident (2026-09-16)
`.env` (with a real CryptoRank key) and the local SQLite database were committed and pushed to the remote by mistake. Root cause: every zip delivered in this chat was packed with `zip -x "*.git*"`, which also matches — and therefore strips — the literal file `.gitignore` (its name contains the substring ".git"). So every delivered copy of this project had no working `.gitignore` at all, silently, since the very first delivery. Fixed the exclusion pattern for future deliveries (`-x "*/.git/*"` instead of `-x "*.git*"`) so `.gitignore` itself is never dropped again. The user chose to leave the exposed key as-is (test account); if that changes, rotate it at https://cryptorank.io/public-api/dashboard — git history still contains it even after `.gitignore` is fixed going forward, since removing a file from tracking doesn't erase it from prior commits.
