const platformLabels = { discord: 'Discord', twitter: 'X/Twitter', telegram: 'Telegram' };

export function socialPanel(project,{node,mutate}) {
  const details=node('details',undefined,'assessment');details.append(node('summary','Знайти соціальні посилання в матеріалах'));
  const content=node('div');details.append(content);
  details.addEventListener('toggle',async()=>{
    if(!details.open||content.childNodes.length)return;
    content.append(node('p','Шукаю посилання…','muted'));
    try {
      const response=await fetch('/api/projects/'+project.id+'/social-draft');const draft=await response.json();
      if(!response.ok)throw new Error(draft.error);
      content.replaceChildren(node('p',draft.notice,'muted'));
      if(!draft.items.length){content.append(node('p','У збереженому тексті не знайдено посилань Discord/X/Telegram. Перевірте повне джерело вручну.','muted'));return;}
      const boxes=[];
      for(const item of draft.items) {
        const row=node('div',undefined,'task');const label=node('label',undefined,'plan-choice');const box=node('input');box.type='checkbox';box.disabled=item.added||!project.verified;box.checked=!item.added&&!!project.verified;
        const title=(platformLabels[item.platform]||item.platform)+': '+(item.action==='join'?'приєднатися':'підписатися')+(item.added?' · Уже додано':'');
        label.append(box,node('strong',title));row.append(label);
        const link=node('a',item.link);link.href=item.link;link.target='_blank';link.rel='noopener noreferrer';const linkRow=node('p');linkRow.append(link);row.append(linkRow);
        for(const evidence of item.evidence)row.append(node('blockquote',evidence.text));
        boxes.push({box,id:item.id});content.append(row);
      }
      const button=node('button','Додати вибране до черги дій');button.type='button';button.disabled=!project.verified;
      const status=node('p',project.verified?'':'Спочатку підтвердьте джерело.','muted');status.setAttribute('role','status');
      button.onclick=async()=>{button.disabled=true;try{await mutate('/api/projects/'+project.id+'/social-plan',{scanId:draft.scanId,itemIds:boxes.filter(b=>b.box.checked&&!b.box.disabled).map(b=>b.id)});}catch(e){status.textContent=e.message;button.disabled=false;}};
      content.append(button,status);
    }catch(e){content.replaceChildren(node('p',e.message,'muted'));}
  });
  return details;
}
