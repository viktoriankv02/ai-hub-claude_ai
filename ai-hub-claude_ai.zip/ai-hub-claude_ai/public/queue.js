const platformLabels = { discord: 'Discord', twitter: 'X/Twitter', telegram: 'Telegram' };
const policyLabels = { approval: 'Потребує підпису в гаманці', manual: 'Виконується вручну' };

export function renderQueue(queue, networks, { node, onOpen }) {
  const root = document.querySelector('#queue-content'); if (!root || !queue) return;
  const content = node('div');
  const groups = Object.entries(queue);
  const total = groups.reduce((sum, [, items]) => sum + items.length, 0);
  const approvalCount = groups.reduce((sum, [, items]) => sum + items.filter(i => i.policy === 'approval').length, 0);
  content.append(node('p', 'Готово до дії: ' + total + ' · Потребує підпису в гаманці: ' + approvalCount, 'muted'));
  if (!total) { content.append(node('p', 'Черга порожня. Підготуй дію в картці проєкту (соціальні посилання або ручна підготовка завдання) — вона з’явиться тут.', 'empty')); root.replaceChildren(content); return; }
  for (const [network, items] of groups.sort((a, b) => a[0].localeCompare(b[0]))) {
    const name = networks.find(n => n.id === network)?.name || network;
    const section = node('div', undefined, 'queue-group');
    section.append(node('h4', name + ' · ' + items.length));
    for (const item of items) {
      const row = node('div', undefined, 'queue-row');
      const info = node('div');
      const platformTag = item.preparedPayload.platform ? ' · ' + (platformLabels[item.preparedPayload.platform] || item.preparedPayload.platform) : '';
      info.append(node('strong', item.title + platformTag), node('p', item.projectName + ' · ' + policyLabels[item.policy], 'muted'), node('p', item.preparedPayload.summary, 'ai-review'));
      if (item.preparedPayload.link) { const a = node('a', item.preparedPayload.link); a.href = item.preparedPayload.link; a.target = '_blank'; a.rel = 'noopener noreferrer'; const p = node('p'); p.append(a); info.append(p); }
      const open = node('button', 'До завдання ↗', 'secondary'); open.type = 'button'; open.setAttribute('aria-label', 'До завдання: ' + item.title);
      open.onclick = () => onOpen({ taskId: item.id, projectId: item.projectId });
      row.append(info, open); section.append(row);
    }
    content.append(section);
  }
  root.replaceChildren(content);
}
