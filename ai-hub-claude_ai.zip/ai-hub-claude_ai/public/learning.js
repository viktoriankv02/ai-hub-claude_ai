export function renderLearning(data, { node }) {
  const root = document.querySelector('#learning-content'); if (!root || !data) return;
  const content = node('div');
  content.append(node('h4', 'Надійність джерел'));
  if (!data.sourceReliability.length) {
    content.append(node('p', 'Ще немає проєктів для статистики.', 'muted'));
  } else {
    for (const s of data.sourceReliability) {
      const row = node('div', undefined, 'queue-row');
      row.append(node('strong', s.domain), node('p', `Проєктів: ${s.projects} · З винагородою: ${s.rewarded} · Лише витрати: ${s.expenseOnly} · Без результату: ${s.noOutcome} · Відхилено: ${s.dismissed}`, 'muted'));
      content.append(row);
    }
  }
  content.append(node('h4', 'Виправлення від тебе (враховуються як контекст для інших проєктів)'));
  if (!data.lessons.length) {
    content.append(node('p', 'Ще немає позначених неточностей аналізу.', 'muted'));
  } else {
    for (const l of data.lessons) {
      const row = node('div', undefined, 'queue-row');
      row.append(node('strong', l.projectName), node('p', l.comment, 'ai-review'));
      content.append(row);
    }
  }
  root.replaceChildren(content);
}
