import { createHash } from 'node:crypto';
import { discordJoinLink, twitterFollowLink, telegramJoinLink } from './social-links.mjs';

// Same principle as research-plan.mjs: nothing here is invented. Every item
// is a link that appears verbatim in the verified source text, with the
// exact surrounding text kept as evidence — never a handle or link an LLM
// guessed. A link either is a valid discord/twitter/telegram target or the
// match is silently skipped; there is no "best effort" fallback that could
// hand the user a wrong link to click.

// Twitter/X path segments that are never a real account to follow — without
// this, "https://twitter.com/home" would be extracted as if @home were the
// project's account.
const RESERVED_TWITTER_PATHS = new Set(['home','explore','notifications','messages','i','intent','search','settings','about','tos','privacy','hashtag','share','login','signup','compose']);

const patterns = [
  { platform: 'discord', regex: /https:\/\/(?:discord\.gg|discord\.com\/invite)\/[A-Za-z0-9-]+/g, build: (raw) => discordJoinLink(raw) },
  { platform: 'telegram', regex: /https:\/\/t\.me\/[A-Za-z0-9_]+/g, build: (raw) => telegramJoinLink(raw) },
  { platform: 'twitter', regex: /https:\/\/(?:twitter\.com|x\.com)\/([A-Za-z0-9_]{1,15})(?![A-Za-z0-9_/])/g, build: (raw, handle) => twitterFollowLink(handle) },
];

export function draftSocialActions(snapshot) {
  const text = snapshot.content;
  const items = [];
  const seen = new Set();
  for (const { platform, regex, build } of patterns) {
    for (const match of text.matchAll(regex)) {
      const raw = match[0];
      if (seen.has(raw)) continue; // same link mentioned more than once on the page
      if (platform === 'twitter' && RESERVED_TWITTER_PATHS.has(match[1].toLowerCase())) continue;
      let action;
      try { action = build(raw, match[1]); } catch { continue; } // malformed match — skip, never guess
      seen.add(raw);
      const start = Math.max(0, match.index - 80);
      const end = Math.min(text.length, match.index + raw.length + 80);
      const id = createHash('sha256').update(snapshot.projectId + '|' + snapshot.hash + '|' + platform + '|' + raw).digest('hex').slice(0, 32);
      items.push({ id, platform, action: action.action, link: action.link, evidence: [{ start, end, text: text.slice(start, end) }] });
    }
  }
  return {
    scanId: snapshot.id, hash: snapshot.hash, fetchedAt: snapshot.attemptedAt, method: 'link-extraction-v1', items,
    notice: 'Посилання витягнуті буквально з тексту джерела. Це не підтверджує, що акаунт офіційний чи дія обов’язкова — перевір сам перед кліком.',
  };
}
