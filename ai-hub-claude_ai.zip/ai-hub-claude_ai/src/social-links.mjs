import { httpsUrl } from './domain.mjs';

// Every function here only builds a URL the user clicks themselves in
// their own already-logged-in browser tab. Nothing here ever holds a
// Discord/Twitter/Telegram credential, token, or session — that is a
// deliberate boundary, not an oversight: this app never authenticates as
// the user on a third-party service.

export function discordJoinLink(inviteUrl) {
  const url = httpsUrl(inviteUrl);
  if (!/^https:\/\/(discord\.gg|discord\.com\/invite)\//.test(url)) throw new Error('Очікується посилання-запрошення discord.gg або discord.com/invite');
  return { platform: 'discord', action: 'join', link: url, suggestedText: '' };
}

export function twitterFollowLink(handle) {
  const clean = String(handle || '').replace(/^@/, '').trim();
  if (!/^[A-Za-z0-9_]{1,15}$/.test(clean)) throw new Error('Некоректний X/Twitter handle');
  return { platform: 'twitter', action: 'follow', link: `https://twitter.com/intent/follow?screen_name=${clean}`, suggestedText: '' };
}

export function twitterPostLink(text) {
  const body = String(text || '').trim();
  if (!body || body.length > 280) throw new Error('Текст поста: 1–280 символів');
  return { platform: 'twitter', action: 'post', link: `https://twitter.com/intent/tweet?text=${encodeURIComponent(body)}`, suggestedText: body };
}

export function telegramJoinLink(channelUrl) {
  const url = httpsUrl(channelUrl);
  if (!/^https:\/\/t\.me\//.test(url)) throw new Error('Очікується посилання t.me/...');
  return { platform: 'telegram', action: 'join', link: url, suggestedText: '' };
}

// Convenience dispatcher matching validatePreparedPayload's shape in
// domain.mjs — used by agent code that already knows platform+action from
// a project's description and just needs the right link built safely.
export function buildSocialAction(platform, action, value) {
  if (platform === 'discord' && action === 'join') return discordJoinLink(value);
  if (platform === 'twitter' && action === 'follow') return twitterFollowLink(value);
  if (platform === 'twitter' && action === 'post') return twitterPostLink(value);
  if (platform === 'telegram' && action === 'join') return telegramJoinLink(value);
  throw new Error(`Непідтримувана комбінація платформа/дія: ${platform}/${action}`);
}
