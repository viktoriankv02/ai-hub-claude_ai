import { OutcomeLedger } from './outcomes.mjs';

// "Learning" here is accumulated, verifiable memory — never model
// fine-tuning (see DEVELOPMENT.md/README for why: faster, safer, and the
// user stays able to see and correct exactly what was learned). Two
// signals, both derived entirely from what the user already recorded —
// neither invents a pattern the data doesn't show:
//
// 1. sourceReliability — across all projects, which source domain
//    (incrypted.com, dropstab.com, cryptorank.io, a project's own site...)
//    has actually led to a recorded reward vs a dismissal vs nothing yet.
// 2. lessonsDigest — real corrections from `agentFeedback` (the user
//    marked an analysis "inaccurate" and explained why), pulled across
//    ALL projects, not just the one being analyzed right now — fed back
//    into the next analysis's prompt so the same kind of mistake isn't
//    repeated blindly on a different project.

export function sourceDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return 'unknown'; }
}

export function sourceReliability(store) {
  const outcomes = new OutcomeLedger(store);
  const byDomain = {};
  for (const p of store.list()) {
    const domain = sourceDomain(p.source);
    const bucket = (byDomain[domain] ??= { domain, projects: 0, dismissed: 0, rewarded: 0, expenseOnly: 0, noOutcome: 0 });
    bucket.projects++;
    if (p.workflow === 'dismissed') bucket.dismissed++;
    const records = outcomes.list(p.id).filter(r => !r.voidedAt);
    if (!records.length) bucket.noOutcome++;
    else if (records.some(r => r.kind === 'reward')) bucket.rewarded++;
    else bucket.expenseOnly++;
  }
  return Object.values(byDomain).sort((a, b) => b.projects - a.projects);
}

export function lessonsDigest(store, limit = 10) {
  const lessons = [];
  for (const p of store.list()) {
    const feedback = store.setting('agentFeedback:' + p.id, null);
    if (feedback?.rating === 'inaccurate' && feedback.comment) {
      lessons.push({ projectName: p.name, comment: feedback.comment, createdAt: feedback.createdAt });
    }
  }
  return lessons.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit);
}
