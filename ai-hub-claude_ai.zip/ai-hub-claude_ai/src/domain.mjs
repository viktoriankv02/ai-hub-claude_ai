import { scoreOpportunity } from './core/scorer.ts';
import { networks } from './networks.mjs';

export function requiredText(value, label, max = 500) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw new Error(`${label}: потрібно від 1 до ${max} символів`);
  return value.trim();
}
export function httpsUrl(value) {
  const url = new URL(requiredText(value, 'URL', 2000));
  if (url.protocol !== 'https:' || url.username || url.password) throw new Error('Потрібне HTTPS-посилання без облікових даних');
  return url.href;
}
export function validateProject(input) {
  if (!input || typeof input !== 'object') throw new Error('Некоректний проєкт');
  const name = requiredText(input.name, 'Назва', 120);
  if (!networks.some(n => n.id === input.network)) throw new Error('Невідома мережа');
  return { name, network: input.network, source: httpsUrl(input.source), notes: typeof input.notes === 'string' ? input.notes.slice(0, 4000) : '' };
}
export function evaluate(project) {
  const signals = {}; // Source verification alone is not an on-chain or reward signal.
  const result = scoreOpportunity({ id: project.id, name: project.name, vm: project.network === 'sui' ? 'SUI' : 'EVM', stage: 'research', priority: 50, signals, sources: project.verified ? [project.source] : [], actions: [] });
  return { score: result.score, reasons: project.verified ? ['Джерело підтверджено користувачем. Умови винагороди ще не оцінені.'] : ['Джерело потребує ручної перевірки.'], rewardStatus: 'unconfirmed' };
}
export function taskPolicy(kind, verified) {
  if (!verified) return 'blocked';
  if (['bridge', 'swap', 'deploy', 'contract-call', 'mint', 'stake', 'liquidity'].includes(kind)) return 'approval';
  return 'manual'; // No live execution adapter is enabled yet.
}
export const taskKinds = ['research', 'check-in', 'social', 'faucet', 'bridge', 'swap', 'deploy', 'contract-call', 'mint', 'stake', 'liquidity'];

// Social tasks (kind === 'social') carry a `platform` so the UI/agent can
// build the right deep link and suggested text (see social-links.mjs).
// This is a separate, orthogonal dimension from taskKinds/taskPolicy on
// purpose: social actions never move funds, so they stay 'manual' policy
// regardless of platform — no approval-gate needed, just a prepared link
// the user clicks themselves (no credentials ever touch this app).
export const socialPlatforms = ['discord', 'twitter', 'telegram', 'other'];

// Shape the agent (or a human) fills in before a task shows up in the
// review queue (see queue() in store.mjs). Kept intentionally loose —
// on-chain kinds carry chain-specific params no single schema should
// pretend to standardize yet (no execution adapter exists), social kinds
// carry a link+text pair. validatePreparedPayload only checks the generic
// envelope (summary always required, link must be https if present);
// kind-specific structure is the preparer's responsibility.
export function validatePreparedPayload(kind, input) {
  if (!input || typeof input !== 'object') throw new Error('Некоректні дані підготовленої дії');
  const summary = requiredText(input.summary, 'Опис підготовленої дії', 500);
  const link = input.link !== undefined && input.link !== null ? httpsUrl(input.link) : null;
  if (kind === 'social') {
    if (!socialPlatforms.includes(input.platform)) throw new Error('Невідома соціальна платформа');
    return { summary, link, platform: input.platform, suggestedText: typeof input.suggestedText === 'string' ? input.suggestedText.slice(0, 1000) : '' };
  }
  return { summary, link, params: input.params && typeof input.params === 'object' ? input.params : {} };
}
