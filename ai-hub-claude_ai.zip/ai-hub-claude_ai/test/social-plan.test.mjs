import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PlanStore } from '../src/plan-store.mjs';
import { draftSocialActions } from '../src/social-plan.mjs';
import { sources } from '../src/discovery.mjs';

const text = 'Join our community on https://discord.gg/abc123 for support. ' +
  'Follow https://twitter.com/SomeProject for updates. ' +
  'Also see https://twitter.com/home and https://x.com/SomeProject/status/999 which are not accounts. ' +
  'Chat on https://t.me/someProjectChannel too.';
const sample = (hash = 'a') => ({ source: sources[0], text, hash, fetchedAt: new Date().toISOString() });

test('draftSocialActions extracts discord/twitter/telegram links with evidence, skipping reserved paths and post links', () => {
  const s = new PlanStore(':memory:');
  const p = s.saveScan(sample());
  const draft = draftSocialActions(s.snapshot(p.projectId, s.latestEvidence(p.projectId).id));
  const platforms = draft.items.map(i => i.platform).sort();
  assert.deepEqual(platforms, ['discord', 'telegram', 'twitter']);
  const twitterItem = draft.items.find(i => i.platform === 'twitter');
  assert.equal(twitterItem.link, 'https://twitter.com/intent/follow?screen_name=SomeProject');
  // "twitter.com/home" and the /status/ link must never be extracted as accounts to follow
  assert.equal(draft.items.filter(i => i.platform === 'twitter').length, 1);
  for (const item of draft.items) for (const e of item.evidence) assert.equal(e.text, text.slice(e.start, e.end));
  s.close();
});

test('adoptSocialAction requires verification, cites evidence, and is idempotent', () => {
  const s = new PlanStore(':memory:');
  const p = s.saveScan(sample());
  const draft = draftSocialActions(s.snapshot(p.projectId, s.latestEvidence(p.projectId).id));
  assert.throws(() => s.adoptSocialAction(p.projectId, { scanId: draft.scanId, itemIds: [draft.items[0].id] }), /перевірте/);
  s.verify(p.projectId, { evidence: 'Reviewed official docs' });
  const input = { scanId: draft.scanId, itemIds: draft.items.map(i => i.id) };
  assert.equal(s.adoptSocialAction(p.projectId, input).added, draft.items.length);
  assert.equal(s.adoptSocialAction(p.projectId, input).added, 0); // idempotent, no duplicates
  const tasks = s.list().find(proj => proj.id === p.projectId).tasks.filter(t => t.kind === 'social');
  assert.equal(tasks.length, draft.items.length);
  for (const t of tasks) { assert.equal(t.policy, 'manual'); assert.ok(t.preparedPayload.link.startsWith('https://')); }
  // these are immediately queue-ready — no separate manual prepareTask step needed
  const queue = s.queue();
  assert.equal(Object.values(queue).flat().length, draft.items.length);
  s.close();
});

test('adoptSocialAction rejects a stale scan after the source changes', () => {
  const s = new PlanStore(':memory:');
  const p = s.saveScan(sample());
  s.verify(p.projectId, { evidence: 'Reviewed' });
  const draft = draftSocialActions(s.snapshot(p.projectId, s.latestEvidence(p.projectId).id));
  s.saveScan(sample('b'));
  s.verify(p.projectId, { evidence: 'Rechecked' });
  assert.throws(() => s.adoptSocialAction(p.projectId, { scanId: draft.scanId, itemIds: [draft.items[0].id] }), /змінилося/);
  s.close();
});
