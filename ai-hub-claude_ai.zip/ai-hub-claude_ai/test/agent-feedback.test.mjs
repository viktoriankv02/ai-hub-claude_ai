import {test} from 'node:test';import assert from 'node:assert/strict';import {PlanStore} from '../src/plan-store.mjs';import {LocalAgents} from '../src/local-agents.mjs';
test('feedback stays in its own project\'s direct context; the labeled cross-project lessons digest is the one deliberate exception',async()=>{
 // Before learning.mjs existed, this test asserted total isolation: feedback
 // about project P must never appear anywhere in project Q's prompt. That's
 // no longer the full picture on purpose — lessonsDigest() deliberately
 // surfaces past "inaccurate" corrections across ALL projects as a labeled,
 // bounded "Уроки з інших проєктів" section (see learning.mjs/local-agents.mjs),
 // because that cross-project memory is the actual point of the "agents
 // learn" feature. What must still hold: P's feedback never appears in Q's
 // *own* "Зворотний зв'язок користувача" section (the direct, same-project
 // channel) — only inside the clearly separate, clearly labeled lessons text.
 const s=new PlanStore(':memory:');let prompt;
 const a=new LocalAgents(s,async(u,o)=>{prompt=JSON.parse(o.body).messages.at(-1).content;return Response.json({message:{content:'Готово'}});});
 try{const p=s.create({name:'One',network:'unknown',source:'https://example.com/one'}),q=s.create({name:'Two',network:'unknown',source:'https://example.com/two'});
 s.setSetting('agentReview:'+p.id,{createdAt:'revision-1',answer:'Draft'});
 assert.throws(()=>a.feedback({projectId:p.id,rating:'inaccurate',comment:'Fix',reviewCreatedAt:'old'}),/змінився/);
 assert.throws(()=>a.feedback({projectId:p.id,rating:'inaccurate',comment:'',reviewCreatedAt:'revision-1'}),/Поясни/);
 a.feedback({projectId:p.id,rating:'inaccurate',comment:'Prefer testnet activities',reviewCreatedAt:'revision-1'});
 await a.analyze(p.id);assert.ok(prompt.includes('Prefer testnet activities'));
 await a.analyze(q.id);
 const feedbackSection=prompt.split('Уроки з інших проєктів')[0];
 assert.ok(!feedbackSection.includes('Prefer testnet activities'),'must not leak into the direct same-project feedback section');
 assert.ok(prompt.includes('Уроки з інших проєктів')&&prompt.split('Уроки з інших проєктів')[1].includes('Prefer testnet activities'),'must appear only inside the labeled cross-project lessons section');
 a.feedback({projectId:p.id,rating:'clear'});await a.analyze(p.id);assert.ok(!prompt.split('Уроки з інших проєктів')[0].includes('Prefer testnet activities'));assert.equal(s.project(p.id).verified,0);
 }finally{s.close();}
});