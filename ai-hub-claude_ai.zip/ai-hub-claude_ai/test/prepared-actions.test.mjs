import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PlanStore } from '../src/plan-store.mjs';
import { validatePreparedPayload, taskPolicy } from '../src/domain.mjs';

function verifiedProject(s, network = 'base') {
  const { id } = s.create({ name: 'Test Project', network, source: 'https://example.com/docs', notes: '' });
  s.verify(id, { evidence: 'Reviewed official docs' });
  return id;
}

test('liquidity is an approval-gate kind, matching other fund-moving actions', () => {
  assert.equal(taskPolicy('liquidity', true), 'approval');
  assert.equal(taskPolicy('liquidity', false), 'blocked');
});

test('validatePreparedPayload requires a platform for social tasks and an https link when given', () => {
  assert.throws(() => validatePreparedPayload('social', { summary: 'Follow on X' }), /соціальна платформа/);
  const ok = validatePreparedPayload('social', { summary: 'Follow on X', platform: 'twitter', link: 'https://twitter.com/intent/follow?screen_name=x' });
  assert.equal(ok.platform, 'twitter');
  assert.throws(() => validatePreparedPayload('swap', { summary: 'Swap 10 USDC', link: 'javascript:alert(1)' }));
});

test('prepareTask attaches a payload only to a verified project and never before completion', () => {
  const s = new PlanStore(':memory:');
  const projectId = verifiedProject(s);
  const { id: taskId } = s.addTask(projectId, { title: 'Follow project on X', kind: 'social' });
  s.prepareTask(taskId, { summary: 'Follow @project', platform: 'twitter', link: 'https://twitter.com/intent/follow?screen_name=project' });
  const task = s.list()[0].tasks[0];
  assert.equal(task.preparedPayload.platform, 'twitter');
  s.complete(taskId, { evidence: 'Followed' });
  assert.throws(() => s.prepareTask(taskId, { summary: 'again', platform: 'twitter' }), /вже виконано/);
  s.close();
});

test('prepareTask rejects on an unverified project, same as addTask/complete', () => {
  const s = new PlanStore(':memory:');
  const { id: projectId } = s.create({ name: 'Unverified', network: 'base', source: 'https://example.com', notes: '' });
  const { id: taskId } = s.addTask(projectId, { title: 'Swap tokens', kind: 'swap' });
  assert.throws(() => s.prepareTask(taskId, { summary: 'Swap 10 USDC for project token' }), /перевірте/);
  s.close();
});

test('queue groups prepared, incomplete tasks by network and puts approval-gate kinds first', () => {
  const s = new PlanStore(':memory:');
  const baseProject = verifiedProject(s, 'base');
  const arbProject = verifiedProject(s, 'arbitrum');

  const social = s.addTask(baseProject, { title: 'Join Discord', kind: 'social' }).id;
  s.prepareTask(social, { summary: 'Join server', platform: 'discord', link: 'https://discord.gg/abc' });

  const swap = s.addTask(baseProject, { title: 'Swap for LP', kind: 'swap' }).id;
  s.prepareTask(swap, { summary: 'Swap 5 USDC -> TOKEN', params: { amountIn: '5', tokenOut: 'TOKEN' } });

  const bridge = s.addTask(arbProject, { title: 'Bridge to Arbitrum', kind: 'bridge' }).id;
  s.prepareTask(bridge, { summary: 'Bridge 0.01 ETH' });

  // an unprepared task must not appear in the queue at all
  s.addTask(baseProject, { title: 'Research docs', kind: 'research' });

  const queue = s.queue();
  assert.deepEqual(Object.keys(queue).sort(), ['arbitrum', 'base']);
  assert.equal(queue.arbitrum.length, 1);
  assert.equal(queue.base.length, 2);
  // approval-gate (swap) sorts before manual (social) within the same network
  assert.equal(queue.base[0].kind, 'swap');
  assert.equal(queue.base[0].policy, 'approval');
  assert.equal(queue.base[1].policy, 'manual');
  s.close();
});

test('queue never includes a completed task even if it was prepared first', () => {
  const s = new PlanStore(':memory:');
  const projectId = verifiedProject(s);
  const { id: taskId } = s.addTask(projectId, { title: 'Check in', kind: 'check-in' });
  s.prepareTask(taskId, { summary: 'Daily check-in', link: 'https://example.com/checkin' });
  assert.equal(s.queue().base.length, 1);
  s.complete(taskId, { evidence: 'Done' });
  assert.deepEqual(s.queue(), {});
  s.close();
});
