import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PlanStore } from '../src/plan-store.mjs';
import { sourceDomain, sourceReliability, lessonsDigest } from '../src/learning.mjs';
import { LocalAgents } from '../src/local-agents.mjs';
import { OutcomeLedger } from '../src/outcomes.mjs';
import { randomUUID } from 'node:crypto';

test('sourceDomain strips www and tolerates a bad URL instead of throwing', () => {
  assert.equal(sourceDomain('https://www.incrypted.com/airdrops/'), 'incrypted.com');
  assert.equal(sourceDomain('not a url'), 'unknown');
});

test('sourceReliability buckets projects by source domain and recorded outcome', () => {
  const s = new PlanStore(':memory:');
  const outcomes = new OutcomeLedger(s);
  const rewarded = s.create({ name: 'Rewarded', network: 'base', source: 'https://incrypted.com/a', notes: '' }).id;
  outcomes.record(rewarded, { requestId: randomUUID(), kind: 'reward', asset: 'USDC', quantity: '10', amountUsd: '10.00', occurredAt: new Date().toISOString(), evidence: 'Received in wallet' });
  const expenseOnly = s.create({ name: 'CostOnly', network: 'base', source: 'https://incrypted.com/b', notes: '' }).id;
  outcomes.record(expenseOnly, { requestId: randomUUID(), kind: 'expense', asset: 'ETH', quantity: '0.01', amountUsd: '20.00', occurredAt: new Date().toISOString(), evidence: 'Gas paid' });
  s.create({ name: 'Untouched', network: 'base', source: 'https://incrypted.com/c', notes: '' });
  const dismissedId = s.create({ name: 'Dismissed', network: 'base', source: 'https://dropstab.com/x', notes: '' }).id;
  s.setWorkflow(dismissedId, { workflow: 'dismissed' });

  const report = sourceReliability(s);
  const incrypted = report.find(r => r.domain === 'incrypted.com');
  assert.equal(incrypted.projects, 3);
  assert.equal(incrypted.rewarded, 1);
  assert.equal(incrypted.expenseOnly, 1);
  assert.equal(incrypted.noOutcome, 1);
  const dropstab = report.find(r => r.domain === 'dropstab.com');
  assert.equal(dropstab.dismissed, 1);
  s.close();
});

test('a voided outcome does not count toward rewarded/expenseOnly', () => {
  const s = new PlanStore(':memory:');
  const outcomes = new OutcomeLedger(s);
  const id = s.create({ name: 'P', network: 'base', source: 'https://incrypted.com/a', notes: '' }).id;
  const { id: outcomeId } = outcomes.record(id, { requestId: randomUUID(), kind: 'reward', asset: 'USDC', quantity: '5', amountUsd: null, occurredAt: new Date().toISOString(), evidence: 'evidence' });
  outcomes.void(outcomeId, { reason: 'Entered by mistake' });
  const report = sourceReliability(s);
  assert.equal(report.find(r => r.domain === 'incrypted.com').noOutcome, 1);
  s.close();
});

test('lessonsDigest only surfaces "inaccurate" feedback with a comment, newest first, across projects', () => {
  const s = new PlanStore(':memory:');
  const agents = new LocalAgents(s, async () => ({ ok: true, json: async () => ({ message: { content: 'stub' } }) }));
  const a = s.create({ name: 'Project A', network: 'base', source: 'https://incrypted.com/a', notes: '' }).id;
  const b = s.create({ name: 'Project B', network: 'base', source: 'https://incrypted.com/b', notes: '' }).id;
  s.setSetting('agentReview:' + a, { answer: 'x', createdAt: '2026-01-01T00:00:00.000Z' });
  s.setSetting('agentReview:' + b, { answer: 'y', createdAt: '2026-01-02T00:00:00.000Z' });
  agents.feedback({ projectId: a, rating: 'inaccurate', reviewCreatedAt: '2026-01-01T00:00:00.000Z', comment: 'Missed the bridge requirement' });
  agents.feedback({ projectId: b, rating: 'useful', reviewCreatedAt: '2026-01-02T00:00:00.000Z' }); // no comment expected/needed for 'useful'
  const digest = lessonsDigest(s, 10);
  assert.equal(digest.length, 1);
  assert.equal(digest[0].projectName, 'Project A');
  assert.match(digest[0].comment, /bridge/);
  s.close();
});

test('local-agents ask() includes the cross-project lessons digest as labeled context, not fact', async () => {
  const s = new PlanStore(':memory:');
  const a = s.create({ name: 'Project A', network: 'base', source: 'https://incrypted.com/a', notes: '' }).id;
  s.setSetting('agentReview:' + a, { answer: 'x', createdAt: '2026-01-01T00:00:00.000Z' });
  const agents = new LocalAgents(s);
  agents.feedback({ projectId: a, rating: 'inaccurate', reviewCreatedAt: '2026-01-01T00:00:00.000Z', comment: 'Forgot to mention KYC was required' });
  let capturedBody;
  agents.fetcher = async (url, init) => { capturedBody = JSON.parse(init.body); return { ok: true, json: async () => ({ message: { content: 'ok' } }) }; };
  const b = s.create({ name: 'Project B', network: 'base', source: 'https://incrypted.com/b', notes: '' }).id;
  await agents.ask({ projectId: b, message: 'Проаналізуй', recordHistory: false });
  const userMessage = capturedBody.messages.at(-1).content;
  assert.match(userMessage, /Уроки з інших проєктів/);
  assert.match(userMessage, /KYC/);
  assert.match(capturedBody.messages[0].content, /виправлення, які користувач раніше давав щодо ІНШИХ проєктів/);
  s.close();
});
