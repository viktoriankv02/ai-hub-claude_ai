import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Store } from '../src/store.mjs';
import { createApp } from '../src/server.mjs';
import { taskPolicy } from '../src/domain.mjs';
const project = { name: 'Test Ink research', network: 'ink', source: 'https://example.com/campaign', notes: 'Test fixture only' };
test('SQLite preserves projects, tasks, evidence and history after restart', () => {
  const path = join(mkdtempSync(join(tmpdir(), 'drop-hunter-')), 'test.sqlite');
  let store = new Store(path); const p = store.create(project); const t = store.addTask(p.id, { title: 'Read campaign rules', kind: 'research' });
  assert.throws(() => store.complete(t.id, { evidence: 'Read docs' }), /перевірте/);
  store.verify(p.id, { evidence: 'Reviewed official provenance' }); store.complete(t.id, { evidence: 'Read docs' });
  const count = store.history().length; store.complete(t.id, { evidence: 'Read docs' }); assert.equal(store.history().length, count);
  store.close(); store = new Store(path); assert.equal(store.list()[0].tasks[0].evidence, 'Read docs'); assert.equal(store.list()[0].tasks[0].status, 'completed'); store.close();
});
test('rejects unsafe links and missing evidence; financial tasks never autonomous', () => {
  const store = new Store(':memory:');
  assert.throws(() => store.create({ ...project, source: 'javascript:alert(1)' }));
  assert.throws(() => store.create({ ...project, network: 'invalid-network' }));
  const p = store.create(project); assert.throws(() => store.verify(p.id, { evidence: ' ' }));
  assert.equal(store.list()[0].score, 0); assert.equal(store.list()[0].verified, 0);
  for (const kind of ['deploy','bridge','swap','stake','mint','contract-call','liquidity']) assert.equal(taskPolicy(kind, true), 'approval');
  assert.equal(taskPolicy('check-in', true), 'manual'); store.close();
});
test('HTTP round trip, session protection, origin checks and static UI', async () => {
  const store = new Store(':memory:'); const app = createApp(store);
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  try {
    const url = `http://127.0.0.1:${app.address().port}`;
    const state = await (await fetch(`${url}/api/state`)).json();
    assert.equal((await fetch(url)).status, 200);
    assert.equal((await fetch(`${url}/api/state`, { headers: { Origin: 'https://evil.example' } })).status, 403);
    assert.equal((await fetch(`${url}/api/projects`, { method: 'POST' })).status, 403);
    const headers = { 'Content-Type': 'application/json', 'X-Session-Token': state.token };
    assert.equal((await fetch(`${url}/api/projects`, { method: 'POST', headers, body: JSON.stringify(project) })).status, 201);
    assert.equal((await (await fetch(`${url}/api/state`)).json()).projects.length, 1);
    assert.equal((await fetch(`${url}/api/projects`, { method: 'POST', headers, body: '{' })).status, 400);
    assert.equal((await fetch(`${url}/src/store.mjs`)).status, 404);
  } finally { await new Promise(resolve => app.close(resolve)); store.close(); }
});
test('every frontend module app.js imports is actually served (catches a missing server allowlist entry)', async () => {
  // Regression guard: social.js and queue.js were written and imported by
  // app.js but not added to server.mjs's static-file allowlist — the
  // module import 404s silently at the network level, but since it's an ES
  // module import, the failure is fatal and breaks the ENTIRE app, not just
  // the missing feature. Caught only by an actual browser load, not by any
  // store-level test. This asserts every import target resolves, so a
  // future missing entry fails fast here instead of only in a real browser.
  const appJs = await readFile(new URL('../public/app.js', import.meta.url), 'utf8');
  const imports = [...appJs.matchAll(/from ['"]\.\/([\w-]+\.js)['"]/g)].map(m => m[1]);
  assert.ok(imports.length > 5, 'sanity check: app.js should import several modules');
  const store = new Store(':memory:'); const app = createApp(store);
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  try {
    const url = `http://127.0.0.1:${app.address().port}`;
    for (const file of imports) {
      const response = await fetch(`${url}/${file}`);
      assert.equal(response.status, 200, `expected /${file} to be served (add it to server.mjs's files allowlist)`);
      assert.match(response.headers.get('content-type') || '', /javascript/, `expected /${file} to be served as JS`);
    }
  } finally { await new Promise(resolve => app.close(resolve)); store.close(); }
});
test('prepare + queue: agent stages an action, user reviews it via HTTP, never auto-signed', async () => {
  const store = new Store(':memory:'); const app = createApp(store);
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  try {
    const url = `http://127.0.0.1:${app.address().port}`;
    const state = await (await fetch(`${url}/api/state`)).json();
    const headers = { 'Content-Type': 'application/json', 'X-Session-Token': state.token };
    const created = await (await fetch(`${url}/api/projects`, { method: 'POST', headers, body: JSON.stringify(project) })).json();
    await fetch(`${url}/api/projects/${created.id}/verify`, { method: 'POST', headers, body: JSON.stringify({ evidence: 'Checked' }) });
    const task = await (await fetch(`${url}/api/projects/${created.id}/tasks`, { method: 'POST', headers, body: JSON.stringify({ title: 'Swap for pool token', kind: 'swap' }) })).json();
    // empty queue before anything is prepared
    assert.deepEqual(await (await fetch(`${url}/api/queue`)).json(), {});
    const prepareRes = await fetch(`${url}/api/tasks/${task.id}/prepare`, { method: 'POST', headers, body: JSON.stringify({ summary: 'Swap 5 USDC for TOKEN', params: { amountIn: '5' } }) });
    assert.equal(prepareRes.status, 200);
    const queue = await (await fetch(`${url}/api/queue`)).json();
    assert.equal(queue.ink.length, 1);
    assert.equal(queue.ink[0].policy, 'approval');
    assert.equal(queue.ink[0].preparedPayload.params.amountIn, '5');
    // GET /api/queue needs no session token (read-only), unlike the POST that staged it
    assert.equal((await fetch(`${url}/api/queue`)).status, 200);
  } finally { await new Promise(resolve => app.close(resolve)); store.close(); }
});
