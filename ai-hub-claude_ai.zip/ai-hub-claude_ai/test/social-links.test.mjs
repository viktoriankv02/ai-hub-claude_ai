import { test } from 'node:test';
import assert from 'node:assert/strict';
import { discordJoinLink, twitterFollowLink, twitterPostLink, telegramJoinLink, buildSocialAction } from '../src/social-links.mjs';

test('discordJoinLink accepts discord.gg and rejects other hosts', () => {
  assert.equal(discordJoinLink('https://discord.gg/abc123').link, 'https://discord.gg/abc123');
  assert.throws(() => discordJoinLink('https://evil.example/abc123'));
});

test('twitterFollowLink builds an intent URL from a bare or @handle', () => {
  assert.equal(twitterFollowLink('someproject').link, 'https://twitter.com/intent/follow?screen_name=someproject');
  assert.equal(twitterFollowLink('@someproject').link, 'https://twitter.com/intent/follow?screen_name=someproject');
  assert.throws(() => twitterFollowLink('not a handle!'));
});

test('twitterPostLink encodes text and enforces the 280-char limit', () => {
  const result = twitterPostLink('Excited about #Project');
  assert.match(result.link, /^https:\/\/twitter\.com\/intent\/tweet\?text=/);
  assert.equal(result.suggestedText, 'Excited about #Project');
  assert.throws(() => twitterPostLink(''));
  assert.throws(() => twitterPostLink('x'.repeat(281)));
});

test('telegramJoinLink only accepts t.me links', () => {
  assert.equal(telegramJoinLink('https://t.me/someChannel').link, 'https://t.me/someChannel');
  assert.throws(() => telegramJoinLink('https://telegram.me/someChannel'));
});

test('buildSocialAction dispatches to the right builder and rejects unknown combos', () => {
  assert.equal(buildSocialAction('discord', 'join', 'https://discord.gg/abc').platform, 'discord');
  assert.throws(() => buildSocialAction('twitter', 'join', 'x'), /Непідтримувана/);
});
